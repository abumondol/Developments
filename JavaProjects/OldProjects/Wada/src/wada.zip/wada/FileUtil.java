package wada;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;

/**
 *
 * @author mm5gg
 */
public class FileUtil {
    
    
        
}
