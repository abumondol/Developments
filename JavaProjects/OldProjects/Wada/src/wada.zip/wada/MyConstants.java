/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package wada;

/**
 *
 * @author mm5gg
 */
public class MyConstants {
    public static final long nanoMilliFactor = 1000000L;
    
}
